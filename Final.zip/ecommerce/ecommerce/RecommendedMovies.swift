
import UIKit

class RecommendedMovies: UICollectionViewCell {

    @IBOutlet weak var moviePoster: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}

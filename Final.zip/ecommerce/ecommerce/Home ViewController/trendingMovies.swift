


import UIKit

class trendingMovies: UICollectionViewCell {

    @IBOutlet weak var moviePoster: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
